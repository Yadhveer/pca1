# AI usage note

**Tools used:** Claude Code with the provided AGENTS.md, claude.md

**What I delegated:** Part 1 was completely coded by me, with slight bug fixes in the end done by claude. in part 2, i implemented the ioc function and then at the end claude found out a design flaw which picked multiples of the true keylength. i then asked it to explain the workaround and then implement it. Part 3 was coded by claude and then explained to me as i couln't understand the chi-square test. The design of part 4 was implemented by claude to test the tooling. the answers were completely written by me. Part 5 was also written by me, with explanations by claude.

**What I verified myself, and how:**
I verified that the implementation for the encryption and decryption worked correct. the ioc funcition as well.

**One thing I learned from — or caught wrong in — the AI's output:**

