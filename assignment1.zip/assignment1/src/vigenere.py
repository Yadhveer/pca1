#!/usr/bin/env python3
"""Vigenere cipher: encrypt/decrypt plus ciphertext-only cryptanalysis.

Subcommands (called by the wrappers in bin/):
    encrypt      <key> <plaintext-file>
    decrypt      <key> <ciphertext-file>
    keylength    <ciphertext-file>
    cryptanalyze <ciphertext-file> <keylen>
"""
import sys


def normalize(text):
    """Strip everything except letters and uppercase the rest (A1.md Part 1)."""
    return "".join(ch.upper() for ch in text if ch.isalpha())


def read_normalized(path):
    with open(path, "r") as f:
        return normalize(f.read())


def encrypt(key, plaintext):
    ct = ""
    length = len(plaintext)
    key_length = len(key)
    for i in range(length):
        char = chr(((ord(plaintext[i]) - ord('A') + ord(key[i%key_length]) - ord('A'))%26)+ ord('A')) 
        ct += char
    return ct


def decrypt(key, ciphertext):
    pt = ""
    length = len(ciphertext)
    key_length = len(key)
    for i in range(length):
        char = chr(((ord(ciphertext[i]) - ord('A') - ord(key[i%key_length]) + ord('A'))%26)+ ord('A')) 
        pt += char
    return pt


def keylength(ciphertext):
    # A length L whose columns are secretly an interleaving of two of the true
    # key's shifts (L is a divisor of the true key length, e.g. L = K/2) is not
    # monoalphabetic, but it's not random either: half its letters follow one
    # shift and half follow another, so its average IoC lands close to a fixed
    # midpoint threshold -- close enough to clear one set between English and
    # random, well before the scan reaches the true length K. So we don't score
    # candidates against a fixed midpoint; we score them against each other.
    #
    # A multiple of K (e.g. 2K) is still fully monoalphabetic per column, so it
    # scores just as high as K itself -- that's why we still want the SMALLEST
    # length that's competitive with the best score, not just the argmax.
    MAX_KEY_LENGTH = 32

    normal_cipher_text = normalize(ciphertext)
    scores = []
    for key_length in range(1, MAX_KEY_LENGTH + 1):
        columns = ["" for _ in range(key_length)]
        for i, ch in enumerate(normal_cipher_text):
            columns[i % key_length] += ch
        avg_ioc = sum(ioc(col) for col in columns) / key_length
        scores.append((key_length, avg_ioc))

    best_avg = max(avg_ioc for _, avg_ioc in scores)
    NEAR_BEST = 0.9  # divisor-trap lengths land near best_avg*0.78-0.80; true/multiple lengths land near 1.0
    for key_length, avg_ioc in scores:
        if avg_ioc >= NEAR_BEST * best_avg:
            return key_length

    return scores[0][0]

def ioc(text):
    normal_text = normalize(text)
    length = len(normal_text)
    frequency_list = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    for i in normal_text:
        frequency_list[ord(i)-ord('A')] += 1

    numerator = 0
    for i in frequency_list:
        numerator += i*(i-1)

    return numerator/(length*(length-1))



# Standard English letter frequencies, A-Z, as probabilities (not percentages).
ENGLISH_FREQ = [
    0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015,
    0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
    0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
    0.00978, 0.02360, 0.00150, 0.01974, 0.00074,
]


def unshift(column, shift):
    """Undo a Caesar shift of `shift` on every letter (recover the plaintext guess)."""
    return "".join(chr((ord(ch) - ord('A') - shift) % 26 + ord('A')) for ch in column)


def chi_squared(text):
    # Q: what is Eᵢ here, and why divide by it instead of just squaring (Oᵢ-Eᵢ)?
    # Q: for a 15-letter column with no Z in it, what does the Z term contribute?
    n = len(text)
    counts = [0] * 26
    for ch in text:
        counts[ord(ch) - ord('A')] += 1
    score = 0.0
    for i in range(26):
        expected = n * ENGLISH_FREQ[i]
        score += (counts[i] - expected) ** 2 / expected
    return score


def best_shift(column):
    # Q: why do we take the shift that MINIMIZES chi-squared, not maximizes it?
    best_s, best_score = 0, None
    for s in range(26):
        score = chi_squared(unshift(column, s))
        if best_score is None or score < best_score:
            best_score = score
            best_s = s
    return best_s


def cryptanalyze(ciphertext, keylen):
    columns = ["" for _ in range(keylen)]
    for i, ch in enumerate(ciphertext):
        columns[i % keylen] += ch
    key = "".join(chr(best_shift(col) + ord('A')) for col in columns)
    return [key]


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: vigenere.py {encrypt,decrypt,keylength,cryptanalyze} ...")

    cmd = sys.argv[1]
    args = sys.argv[2:]

    if cmd == "encrypt":
        key, path = args
        ciphertext = encrypt(normalize(key), read_normalized(path))
        print(ciphertext)

    elif cmd == "decrypt":
        key, path = args
        plaintext = decrypt(normalize(key), read_normalized(path))
        print(plaintext)

    elif cmd == "keylength":
        (path,) = args
        print(keylength(read_normalized(path)))

    elif cmd == "cryptanalyze":
        path, k = args
        for candidate in cryptanalyze(read_normalized(path), int(k)):
            print(candidate)

    else:
        sys.exit("unknown subcommand: " + cmd)


if __name__ == "__main__":
    main()
