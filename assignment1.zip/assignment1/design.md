# Design note (≤ 1 page)

## Key-length decision rule (Part 2)
<!-- What is scored for each candidate length? How do you choose among candidates?
     What happens at a multiple of the true length? Ties? -->

For each length L (1–20), split into L columns, average their IoC, and return the first L that clears THRESHOLD ≈ 0.052, scanning smallest to largest, rather than the single best-scoring L. Falls back to the best seen if nothing clears threshold.
Smallest-first matters because multiples of the true length K (like 2K) also produce pure single-shift columns and look just as English, but they're always bigger than K, so stopping early finds K first.


## Column-shift scoring (Part 3)
<!-- Which statistic? What are its reference quantities? Is the correct shift a
     minimum or a maximum, and why? How do you produce alternative candidates? -->

Given the key length, split into columns and, for each, undo all 26 shifts and compare letter counts to English frequencies via chi-squared. The best shift minimizes chi-squared, since lower means closer to expected English.
Currently only one candidate keyword comes out (argmin shift per column) — no shortlist of near-best shifts per column to combine into alternates when the argmin is wrong.


## Known failure cases
<!-- Short texts, long keys, non-English, degenerate keys (AAAA), other alphabets… -->
the main one is the divisor trap, where an even K lets the guess L = K/2 produce columns that alternate between just two keyword letters instead of mixing many, which turns out to be lumpy enough to beat threshold and get falsely returned before the scan ever reaches K (this hits K=10 and K=20 specifically, not primes or 15, and doesn't go away with more data since it's a structural bias rather than noise). Separately, short columns are a problem whenever k is large and n is small, since there just aren't enough letters per column for IoC or chi-squared to be reliable, though this one does improve as more ciphertext is added. Beyond that, the tool assumes English plaintext, so it'll struggle on anything else since both statistics are built around an English reference table; it handles degenerate keys like "AAAA" without complaint, even though recovering them is trivial and not very meaningful; and it only works on a plain 26-letter alphabet, since normalize() strips out punctuation, spacing, and case before analysis, so any of that information is simply lost.