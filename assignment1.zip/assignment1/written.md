# Part 5 — Written questions

## 1. Long keys
Our whole cryptanalysis of the Vigenere cipher revolves around the fact that the key repeats after a certain length, the length being the length of the key. If the key is at least as long as the message and never reused, every single ciphertext letter is shifted by a different, independent key letter. There's no repetition.

Conditions for the security to hold:
1. the key shouldn't be reused. the same key repetition vulnerability occurs.
2. the letters of the key should be completely random.
3. key should be as long as the plaintext.
4. key should be kept secret

## 2. Why IoC works
IOC is just the probability that 2 letters picked at random, they are the same letter. when we assume a keylength and its correct, it means that all the respective plaintext letters have the same amount of shift. so the ciphertext letters would be different but the probability would remain the same. It doesn't matter which specific letter is picked. when the keylength is picked wrong the probability distribution shifts and becomes low.

If two positions fall in the same column when split by the assumed keylength(k), and k is a multiple of the true keylength(K), then they also fall in the same column when split by the real K. Which means these multiples will also show high, English-like IoC.

Since 2K, 3K, etc. are always bigger than K, scanning candidate lengths from small to large and stopping at the first one that clears the threshold will hit the true K first.

## 3. Kasiski vs. IoC
Kasiski's method looks for repeated chunks of ciphertext and measures the distance between repeats. If a plaintext fragment repeats and lines up with the same part of the keyword both times, you get an identical ciphertext fragment — and that distance has to be a multiple of the key length.

Kasiski doesn't get fooled by the multiple problem, every real repeat distance is a multiple of the actual K.
For a short ciphertext with no repeats Kasiski comes up with nothing. IOC just needs enough letters per column to analyze the cipher.

## 4. IoC as a fitness function (Enigma plugboard)
Readability is all-or-nothing, but IoC isn't. Each correct cable nudges two letters closer to normal, regardless of what else is still wrong, so the score creeps up steadily long before anything's actually readable, which is exactly the gradual signal a hill-climb needs. That gradual signal eventually runs out, though: IoC only tracks overall letter proportions, not order, so once most cables are right the histogram's already basically correct and the signal dries up. That's where trigrams take over, since they check whether letters make sense together, so they keep improving all the way to the end. You can't start with trigrams though, because with almost everything still wrong, every trigram looks like garbage no matter what we changed, so there's nothing to climb yet.