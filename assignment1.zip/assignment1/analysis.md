# Part 4 — Empirical analysis

## Procedure
Corpus: `corpus.txt` (563940 normalized letters, Project Gutenberg, *Pride and Prejudice*). 50 trials per (k, n) cell. Each trial: a fresh uniformly random key of length k over A-Z, and a uniformly random contiguous n-letter window of the corpus.

## Key-length recovery (Part 2): fraction of exact recoveries

| k \ n | 100 | 200 | 500 | 1000 | 2000 | 5000 | 20000 |
|---|---|---|---|---|---|---|---|
| 3 | 0.64 | 0.88 | 0.94 | 0.94 | 0.94 | 0.88 | 0.98 |
| 5 | 0.82 | 0.98 | 0.98 | 1.00 | 1.00 | 1.00 | 1.00 |
| 7 | 0.74 | 0.98 | 0.98 | 1.00 | 1.00 | 1.00 | 1.00 |
| 10 | 0.32 | 0.54 | 0.48 | 0.62 | 0.48 | 0.72 | 0.60 |
| 15 | 0.22 | 0.76 | 0.98 | 1.00 | 1.00 | 1.00 | 1.00 |
| 20 | 0.06 | 0.50 | 0.64 | 0.64 | 0.52 | 0.64 | 0.56 |

## Key recovery (Part 3): fraction of exact recoveries

| k \ n | 100 | 200 | 500 | 1000 | 2000 | 5000 | 20000 |
|---|---|---|---|---|---|---|---|
| 3 | 0.94 | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| 5 | 0.64 | 0.96 | 1.00 | 1.00 | 1.00 | 1.00 | 1.00 |
| 7 | 0.20 | 0.74 | 0.98 | 1.00 | 1.00 | 1.00 | 1.00 |
| 10 | 0.06 | 0.38 | 0.94 | 1.00 | 1.00 | 1.00 | 1.00 |
| 15 | 0.00 | 0.08 | 0.74 | 1.00 | 1.00 | 1.00 | 1.00 |
| 20 | 0.00 | 0.00 | 0.32 | 0.98 | 1.00 | 1.00 | 1.00 |

## Where and why it breaks (≤ 300 words, your own reasoning)
For part 2, my tool got high accuracies for keys of length 3,5,7,15, but struggled with keys of length 10 and 20. The same goes for part 3 as well. The tool also struggles with shorter ciphertext length. My guess for why it fails for shorter ciphertext lengths is that a small sample size isn't enough to determine that a particular coset's shift resembles the english alphabet with a high index of cincidence. for example, if k=20 and n=100, each coset only has about 5 letters, which isn't enough to determine IOC. As n grows, the noice averages out into true shift.

As to why k=10,20 have high inaccuracy. the other keys are prime numbers, in case of 10 and 20, when assuming keyword_length = 5 or 10, only certain letters of the keyword are responsible for the shift. the keyword just keeps alternating between 2 letters. Even with a bigger ciphertext this isn't solved because this problem doesn't arise due to random noise, the 2 letter shift problem, the index of coincidence converges around to where a 2 shift text normally sits.

## Does Part 3 fail at the same boundary as Part 2? (one sentence)
No, part 3 fails at only small sample sizes, regardless of wether k is prime or not.